# Hướng dẫn chạy dự án trong VSCode (máy local)

Tài liệu này dành cho việc chạy Giai đoạn 4 (Tuần 5) trên máy cá nhân
bằng VSCode, thay vì Google Colab như các giai đoạn trước. Các giai
đoạn 1-3 vẫn có thể tiếp tục chạy trên Colab như cũ nếu muốn — code đã
được sửa để tự nhận diện đang chạy ở Colab hay máy local, không cần
sửa gì thêm khi chuyển qua lại.

## 1. Cấu trúc thư mục cần có

Tạo cấu trúc thư mục sau trên máy (tên `DoAn` chỉ là ví dụ, có thể đặt
tên khác miễn giữ đúng cấu trúc con):

```
DoAn/
  code/                          <- toàn bộ file .py của dự án, mở thư mục này bằng VSCode
    data_prep.py
    episode_utils.py
    train_protonet.py
    train_baseline_finetune.py
    stage4_run_all.py
    compare_results.py
    requirements.txt
  data/                          <- CÙNG CẤP với code/, không nằm trong code/
    plantvillage/
      plantvillage-dataset.zip   <- tải từ Kaggle, giữ nguyên file zip, không tự giải nén
    durian/
      A Durian Leaf Image Dataset of Common Diseases in Vietnam for Agricultural Diagnosis/
        Durian_Leaf_Diseases/
          train/...
          val/...
          test/...
  models/                        <- tự động được tạo, nơi lưu file .pt
  results/                       <- tự động được tạo, nơi lưu file .json/.md/.csv kết quả
```

Thư mục `data/durian/...` chính là thư mục bạn upload (file
`durian-...zip`), giải nén ra và đặt đúng vị trí như trên.

Nếu muốn đặt thư mục `data/` ở chỗ khác (ví dụ ổ D:), đặt biến môi
trường trước khi chạy:

```
# Windows (PowerShell)
$env:DOAN_DATA_DIR = "D:\DoAn\data"

# macOS / Linux
export DOAN_DATA_DIR=/duong/dan/den/DoAn/data
```

## 2. Cài môi trường trong VSCode

1. Mở thư mục `DoAn/code` bằng VSCode (File > Open Folder).
2. Mở Terminal trong VSCode (Ctrl + `), tạo virtual environment:

   ```
   python -m venv .venv
   ```

3. Kích hoạt virtual environment:

   ```
   # Windows
   .venv\Scripts\activate

   # macOS / Linux
   source .venv/bin/activate
   ```

   VSCode thường tự hỏi "Select this environment" — chọn Yes để dùng
   `.venv` này cho cả việc chạy file lẫn debug.

4. Cài thư viện:

   ```
   pip install -r requirements.txt
   ```

   Nếu máy có GPU NVIDIA và muốn train nhanh hơn, cài bản torch có CUDA
   theo hướng dẫn tại https://pytorch.org/get-started/locally/ thay vì
   dòng `pip install torch` mặc định trong requirements.txt.

## 3. Chạy Giai đoạn 2 (chuẩn bị dữ liệu) — chỉ cần chạy 1 lần

```
python data_prep.py
```

Kết quả mong đợi: không lỗi, in ra bảng số lượng ảnh mỗi lớp, tạo file
`data/class_to_images.json`. Đây là cache dùng cho mọi bước sau, không
cần chạy lại trừ khi đổi bộ dữ liệu.

Lưu ý: lần chạy đầu sẽ giải nén PlantVillage (mất vài phút do nhiều
ảnh), các lần chạy sau sẽ tự bỏ qua bước này vì đã có sẵn.

## 4. Chạy Giai đoạn 4 (Tuần 5 — Huấn luyện & Đánh giá)

Chạy từng bước bằng cờ `--stage`, đúng theo phân công Người 1 / Người 2
trong checklist:

```
# Người 1 chạy trên máy của mình
python stage4_run_all.py --stage protonet

# Người 2 chạy trên máy của mình (không cần chờ Người 1 xong)
python stage4_run_all.py --stage baseline

# Sau khi CẢ 2 đã có file .pt/.json trong models/ (đồng bộ qua Drive
# hoặc chép tay), Người 2 chạy benchmark cho cả 2 mô hình cùng lúc,
# cùng máy, đảm bảo so sánh công bằng
python stage4_run_all.py --stage evaluate

# Cả 2 cùng xem bảng kết quả cuối
python stage4_run_all.py --stage compare
```

Muốn tự kiểm tra toàn bộ pipeline chạy được từ đầu đến cuối trên 1 máy
duy nhất (ví dụ để debug trước khi giao việc thật), dùng:

```
python stage4_run_all.py --stage all
```

### Nếu 2 người chạy ở 2 máy khác nhau

`models/` và `results/` nằm cùng cấp với `data/` (do
`episode_utils.py` tự đặt `MODELS_DIR`/`RESULTS_DIR` dựa trên
`DRIVE_BASE_DIR`). Sau khi Người 1 chạy xong `--stage protonet` và
Người 2 chạy xong `--stage baseline`, cần đồng bộ 2 thư mục này (copy
qua Google Drive, USB, hay Git — miễn 2 người có chung nội dung) trước
khi chạy `--stage evaluate`, vì bước này cần đọc lại checkpoint của cả
2 người.

## 5. Chạy debug từng file trong VSCode (không dùng terminal)

Có thể nhấn nút "Run and Debug" (F5) trên từng file `.py` để chạy độc
lập, ví dụ mở `train_protonet.py` rồi F5 sẽ tự train + evaluate riêng
ProtoNet (dùng khối `if __name__ == '__main__':` cuối mỗi file). Cách
này tiện khi cần đặt breakpoint kiểm tra giá trị tensor giữa chừng.

## 6. Kết quả sau khi chạy xong Giai đoạn 4

Trong thư mục `results/` sẽ có:

- `protonet_1shot.json`, `protonet_5shot.json`, `protonet_10shot.json`
- `baseline_finetune_1shot.json`, `baseline_finetune_5shot.json`, `baseline_finetune_10shot.json`
- `baseline_tuning_summary_1shot.json` (và tương tự cho 5shot/10shot) — quá trình tune ft_steps/ft_lr
- `protonet_training_summary.json` — lịch sử loss/accuracy qua từng epoch
- `comparison_table.md` — bảng so sánh cuối, dán thẳng vào báo cáo đồ án
- `comparison_table.csv` — cùng dữ liệu, dùng để vẽ biểu đồ trong Excel/Google Sheets

Trong thư mục `models/` sẽ có:

- `protonet_conv4_best.pt`, `protonet_conv4_final.pt`
- `baseline_mobilenetv2_backbone.pt`, `baseline_finetune_config.json`
