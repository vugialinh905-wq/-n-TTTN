# -*- coding: utf-8 -*-
"""
train_baseline_finetune.py
Giai đoạn 3 — Người 2: Baseline Fine-tuning (đối chứng với Prototypical Network)

Nguyên tắc so sánh công bằng:
- Dùng ĐÚNG hạ tầng episode_utils.py (cùng cách rút episode, cùng seed,
  cùng số episode đánh giá) như bên Người 1 — xem evaluate_episodes().
- Với mỗi episode, model KHÔNG được biết trước các lớp đó — ta fine-tune
  nhanh CHỈ trên support set của episode đó (đúng K ảnh/lớp), rồi test
  trên query set của CHÍNH episode đó. Đây là cách so sánh công bằng nhất
  với few-shot learning: cùng điều kiện chỉ có K ảnh mỗi lớp để "học".

Yêu cầu chạy trước file này (đúng thứ tự):
1. data_prep.py     — đã tạo xong class_to_images.json trong Drive
2. episode_utils.py — nằm cùng thư mục, import được
"""

import os
import json
import time

import torch
import torch.nn as nn
import torchvision.models as tvm

from data_prep import set_seed, N_WAY, K_SHOT, SEED
from episode_utils import (
    DEVICE, MODELS_DIR, RESULTS_DIR, load_meta, evaluate_episodes, save_result,
)

EVAL_EPISODES = 600

# Giá trị mặc định — sẽ bị GHI ĐÈ bởi kết quả tune trên validation_classes
# (xem tune_hyperparams_on_validation), không dùng cố định như trước nữa.
FT_STEPS = 50   # số bước gradient fine-tune trên mỗi episode
FT_LR = 1e-3

# Lưới tham số thử trên validation — giữ nhỏ để không tốn quá nhiều thời
# gian, nhưng đủ để không chọn tham số "đoán mò"
FT_STEPS_CANDIDATES = [20, 50, 100]
FT_LR_CANDIDATES = [1e-3, 5e-3, 1e-2]
N_VAL_EPISODES = 100  # ít hơn 600 vì chỉ dùng để SO SÁNH các cấu hình, không phải kết quả cuối

# Giai đoạn 4: baseline không có 1 checkpoint "học xong" như ProtoNet
# (vì classifier được fine-tune lại từ đầu ở MỖI episode). Phần "model"
# ổn định duy nhất có thể lưu lại là backbone MobileNetV2 đã đóng băng
# (để người 1 hoặc người chấm có thể tải lại đúng đặc trưng đã dùng,
# không phải tự tải pretrained weights lần nữa và lo version lệch nhau).
BACKBONE_CKPT_PATH = os.path.join(MODELS_DIR, 'baseline_mobilenetv2_backbone.pt')


# ============================================================
# 1. MODEL GỐC — MobileNetV2 pretrained trên ImageNet
# ============================================================

def build_pretrained_backbone():
    """Tải MobileNetV2 pretrained, bỏ lớp classifier gốc (1000 lớp
    ImageNet), giữ lại phần feature extractor để gắn classifier mới cho
    từng episode. Backbone được ĐÓNG BĂNG (không train lại toàn bộ mạng),
    vì K ảnh quá ít để fine-tune an toàn cả mạng lớn — chỉ train lớp
    classifier cuối, đây là cách làm hợp lý và phổ biến khi so sánh với
    few-shot learning trong điều kiện dữ liệu hạn chế."""
    model = tvm.mobilenet_v2(weights=tvm.MobileNet_V2_Weights.IMAGENET1K_V1)
    model.classifier = nn.Identity()
    model.eval()
    for p in model.parameters():
        p.requires_grad = False
    return model.to(DEVICE)


# ============================================================
# 2. FINE-TUNE NHANH TRÊN 1 EPISODE
# ============================================================

def finetune_on_episode(base_model, support_x, support_y, n_way,
                         ft_steps=FT_STEPS, ft_lr=FT_LR):
    """Gắn 1 lớp Linear mới (n_way classes) lên trên đặc trưng đã trích
    xuất, chỉ fine-tune lớp Linear này bằng đúng K ảnh/lớp của episode
    hiện tại. ft_steps/ft_lr có thể truyền riêng để dùng trong lúc tune
    hyperparameter trên validation, khác với giá trị mặc định cuối cùng
    dùng để đánh giá trên novel classes."""
    with torch.no_grad():
        support_feat = base_model(support_x)  # backbone đóng băng, trích 1 lần
    feat_dim = support_feat.shape[1]

    classifier = nn.Linear(feat_dim, n_way).to(DEVICE)
    optimizer = torch.optim.Adam(classifier.parameters(), lr=ft_lr)
    criterion = nn.CrossEntropyLoss()

    classifier.train()
    for _ in range(ft_steps):
        optimizer.zero_grad()
        logits = classifier(support_feat)
        loss = criterion(logits, support_y)
        loss.backward()
        optimizer.step()

    classifier.eval()
    return classifier


# ============================================================
# 3. HÀM PREDICT — đúng chữ ký evaluate_episodes() yêu cầu
#    (bao gồm CẢ thời gian fine-tune trong lúc đo inference time,
#    vì đây là chi phí thực tế phải trả khi gặp lớp mới — so sánh công
#    bằng với ProtoNet, vốn không cần fine-tune lại lúc gặp lớp mới)
# ============================================================

def make_predict_fn(base_model, n_way, ft_steps=FT_STEPS, ft_lr=FT_LR):
    def predict_fn(support_x, support_y, query_x):
        classifier = finetune_on_episode(base_model, support_x, support_y, n_way,
                                          ft_steps=ft_steps, ft_lr=ft_lr)
        with torch.no_grad():
            query_feat = base_model(query_x)
            logits = classifier(query_feat)
            return logits.argmax(dim=1)
    return predict_fn


# ============================================================
# 3b. TUNE FT_STEPS / FT_LR TRÊN VALIDATION — còn thiếu ở bản trước.
#     Trước đây 2 tham số này bị đặt cố định (đoán mò), trong khi bên
#     ProtoNet của Người 1 đã dùng validation_classes để chọn checkpoint
#     tốt nhất. Nếu baseline không được "tune" tương xứng, phần so sánh
#     ở Giai đoạn 5 sẽ THIÊN VỊ cho ProtoNet một cách không công bằng.
# ============================================================

def tune_hyperparams_on_validation(base_model, class_to_images, validation_classes,
                                    k_shot=K_SHOT):
    """Thử vài cấu hình (ft_steps, ft_lr) trên validation_classes (Pepper),
    chọn cấu hình có accuracy trung bình cao nhất — đúng vai trò của tập
    validation theo checklist Giai đoạn 0.

    Giai đoạn 4 — CẬP NHẬT: nhận thêm tham số k_shot, vì cấu hình
    ft_steps/ft_lr tốt nhất cho 1-shot (rất ít dữ liệu, dễ overfit nếu
    train quá nhiều bước) không nhất thiết tốt nhất cho 10-shot. Tune
    riêng cho từng K để so sánh với ProtoNet công bằng ở mọi cấu hình,
    thay vì chỉ tune 1 lần dùng chung cho cả 3 cấu hình như bản trước.

    LỖI ĐÃ SỬA (phát hiện khi test Giai đoạn 4): validation_classes
    (Pepper) chỉ có 2 lớp, trong khi N_WAY mặc định = 5. Gọi thẳng
    N_WAY=5 ở đây làm random.sample() báo lỗi "Sample larger than
    population" — cùng lỗi mà train_protonet.py (quick_validate) đã
    gặp và tự sửa trước đó. Sửa tương tự: val_n_way = min(N_WAY,
    len(validation_classes))."""
    val_n_way = min(N_WAY, len(validation_classes))
    if val_n_way < 2:
        raise ValueError(
            f"Không đủ lớp validation để tune (chỉ có {len(validation_classes)} "
            f"lớp). Cần ít nhất 2 lớp validation."
        )

    print(f"Đang tune FT_STEPS / FT_LR trên validation classes cho "
          f"{k_shot}-shot ({val_n_way}-way, {len(validation_classes)} lớp có sẵn, "
          f"{N_VAL_EPISODES} episode/cấu hình)...")

    best_acc = -1.0
    best_params = (FT_STEPS, FT_LR)
    tuning_log = []

    for steps in FT_STEPS_CANDIDATES:
        for lr in FT_LR_CANDIDATES:
            predict_fn = make_predict_fn(base_model, val_n_way, ft_steps=steps, ft_lr=lr)
            result = evaluate_episodes(
                predict_fn, class_to_images, validation_classes,
                n_episodes=N_VAL_EPISODES, n_way=val_n_way, k_shot=k_shot,
            )
            acc = result['mean_accuracy']
            print(f"  ft_steps={steps:3d}, ft_lr={lr:.0e} -> "
                  f"val acc = {acc:.4f}")
            tuning_log.append({'ft_steps': steps, 'ft_lr': lr, 'val_accuracy': acc})

            if acc > best_acc:
                best_acc = acc
                best_params = (steps, lr)

    best_steps, best_lr = best_params
    print(f"  -> Đã chọn cho {k_shot}-shot: FT_STEPS={best_steps}, "
          f"FT_LR={best_lr:.0e} (validation accuracy = {best_acc:.4f})")

    # Lưu lại toàn bộ quá trình tune để đưa vào báo cáo (đúng tinh thần
    # AI Development Log / giải trình phương pháp — không phải "đoán mò").
    # Mỗi K lưu 1 file riêng để không ghi đè lẫn nhau.
    summary_path = os.path.join(RESULTS_DIR, f'baseline_tuning_summary_{k_shot}shot.json')
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump({
            'k_shot': k_shot,
            'candidates': tuning_log,
            'best_ft_steps': best_steps,
            'best_ft_lr': best_lr,
            'best_val_accuracy': best_acc,
        }, f, ensure_ascii=False, indent=2)
    print(f"  -> Đã lưu tóm tắt quá trình tune tại: {summary_path}")

    return best_steps, best_lr


# ============================================================
# 3c. "TRAIN" & LƯU MODEL — Giai đoạn 4, checklist Người 2
#     Baseline không có vòng lặp train dài như ProtoNet (backbone đã
#     pretrained sẵn và bị đóng băng), nên "train xong" ở đây nghĩa là:
#     (1) tải + đóng băng backbone, (2) tune FT_STEPS/FT_LR CHO TỪNG cấu
#     hình K trên validation_classes, (3) lưu backbone + toàn bộ cấu
#     hình đã tune vào Drive/thư mục models, để bước evaluate() sau này
#     (và người khác đọc lại) không phải chạy lại bước tune tốn thời gian.
# ============================================================

def train_and_save():
    """Chạy đúng 1 lần cho cả 3 cấu hình K = 1, 5, 10 — trả về dict
    {k_shot: (ft_steps, ft_lr)} để evaluate() dùng lại ngay, không cần
    đọc lại file JSON trong cùng phiên chạy."""
    set_seed(SEED)
    meta = load_meta()
    class_to_images = meta['class_to_images']
    validation_classes = meta['validation_classes']

    base_model = build_pretrained_backbone()

    # Lưu backbone 1 lần — dùng chung cho mọi K, vì backbone bị đóng
    # băng (không đổi giữa các cấu hình K khác nhau)
    torch.save(base_model.state_dict(), BACKBONE_CKPT_PATH)
    print(f"Đã lưu backbone (MobileNetV2, đóng băng) tại: {BACKBONE_CKPT_PATH}")

    tune_start = time.time()
    best_params_per_k = {}
    for k in [1, 5, 10]:
        best_steps, best_lr = tune_hyperparams_on_validation(
            base_model, class_to_images, validation_classes, k_shot=k
        )
        best_params_per_k[k] = (best_steps, best_lr)
    tune_time_sec = time.time() - tune_start

    # Lưu tổng hợp cấu hình đã chọn cho cả 3 K vào 1 file — đây là
    # "model" theo đúng nghĩa checklist yêu cầu: backbone (.pt) +
    # cấu hình (.json) đi kèm là đủ để tái tạo lại đúng cách baseline
    # đã hoạt động, không cần lưu lại classifier (vì nó được huấn luyện
    # lại từ đầu ở mỗi episode, không có ý nghĩa lưu trữ lâu dài).
    config_path = os.path.join(MODELS_DIR, 'baseline_finetune_config.json')
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump({
            'backbone': 'mobilenetv2_imagenet1k_v1_frozen',
            'backbone_ckpt_path': BACKBONE_CKPT_PATH,
            'tune_time_sec': tune_time_sec,
            'best_params_per_k': {str(k): {'ft_steps': s, 'ft_lr': lr}
                                   for k, (s, lr) in best_params_per_k.items()},
        }, f, ensure_ascii=False, indent=2)
    print(f"Đã lưu cấu hình baseline (cả 3 K) tại: {config_path}")
    print(f"Tổng thời gian tune (3 cấu hình K): {tune_time_sec / 60:.1f} phút")

    return base_model, best_params_per_k


# ============================================================
# 4. CHẠY ĐÁNH GIÁ — dùng ĐÚNG hạ tầng chung (episode_utils.py)
# ============================================================

def load_trained_config(config_path=None):
    """Giai đoạn 4: nạp lại backbone + cấu hình (ft_steps, ft_lr) mà
    Người 2 đã train_and_save() và lưu vào Drive, KHÔNG cần tune lại
    từ đầu (bước tune khá tốn thời gian vì thử cả lưới tham số)."""
    if config_path is None:
        config_path = os.path.join(MODELS_DIR, 'baseline_finetune_config.json')
    if not os.path.exists(config_path) or not os.path.exists(BACKBONE_CKPT_PATH):
        raise FileNotFoundError(
            f"Không tìm thấy cấu hình/backbone đã lưu ({config_path} hoặc "
            f"{BACKBONE_CKPT_PATH}). Cần chạy train_and_save() trước."
        )
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)

    base_model = tvm.mobilenet_v2(weights=None)
    base_model.classifier = nn.Identity()
    base_model.load_state_dict(torch.load(BACKBONE_CKPT_PATH, map_location=DEVICE))
    base_model.eval()
    for p in base_model.parameters():
        p.requires_grad = False
    base_model = base_model.to(DEVICE)

    best_params_per_k = {
        int(k): (v['ft_steps'], v['ft_lr'])
        for k, v in config['best_params_per_k'].items()
    }
    print(f"Đã nạp baseline (backbone + cấu hình 3 K) từ: {config_path}")
    return base_model, best_params_per_k


def evaluate(base_model=None, best_params_per_k=None):
    """Đánh giá trên novel classes (Durian), 600 episode, cho cả 3 cấu
    hình K = 1, 5, 10. Nếu chưa có model/cấu hình sẵn (ví dụ gọi file
    này độc lập, không qua stage4_run_all.py), tự train_and_save()
    trước — GIỮ NGUYÊN hành vi "chạy 1 file là xong" như bản cũ."""
    set_seed(SEED)
    meta = load_meta()
    class_to_images = meta['class_to_images']
    novel_classes = meta['novel_classes']

    if base_model is None or best_params_per_k is None:
        base_model, best_params_per_k = train_and_save()

    for k in [1, 5, 10]:
        best_ft_steps, best_ft_lr = best_params_per_k[k]
        print(f"\n--- Đánh giá {N_WAY}-way {k}-shot (Fine-tuning baseline, "
              f"ft_steps={best_ft_steps}, ft_lr={best_ft_lr:.0e}) ---")
        predict_fn = make_predict_fn(base_model, N_WAY,
                                      ft_steps=best_ft_steps, ft_lr=best_ft_lr)
        result = evaluate_episodes(
            predict_fn, class_to_images, novel_classes,
            n_episodes=EVAL_EPISODES, k_shot=k,
        )
        result['method'] = 'Fine-tuning (MobileNetV2)'
        result['ft_steps'] = best_ft_steps
        result['ft_lr'] = best_ft_lr
        print(f"Accuracy: {result['mean_accuracy']:.4f} ± {result['ci95']:.4f} "
              f"| thời gian TB mỗi episode (gồm cả fine-tune): "
              f"{result['mean_inference_time_sec']*1000:.2f} ms")
        save_result(result, f'baseline_finetune_{k}shot.json')


if __name__ == '__main__':
    evaluate()
