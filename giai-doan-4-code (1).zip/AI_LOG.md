# AI Development Log

## Phiên 1 — Chuẩn bị dữ liệu (data_prep.py)
- Công cụ: Claude (Anthropic)
- Ngày: [điền ngày thực tế]
- Mục tiêu: Xây pipeline đọc PlantVillage + Durian, chia base/validation/novel classes
- File liên quan: data_prep.py

## Phiên 2 — Hạ tầng episode & Prototypical Network
- Công cụ: Claude (Anthropic)
- Ngày: [điền ngày thực tế]
- Mục tiêu: Viết episode_utils.py (hạ tầng dùng chung), train_protonet.py
  (Conv-4 backbone, episodic training), train_baseline_finetune.py
  (baseline đối chứng)
- File liên quan: episode_utils.py, train_protonet.py, train_baseline_finetune.py
- Lỗi phát sinh & tự sửa: quick_validate() dùng N_WAY=5 mặc định trong
  khi validation_classes (Pepper) chỉ có 2 lớp -> lỗi "Sample larger
  than population". Tự sửa bằng val_n_way = min(N_WAY, len(validation_classes))

## Phiên 3 — Debug môi trường Colab/Drive
- Công cụ: Claude (Anthropic)
- Ngày: [điền ngày thực tế]
- Mục tiêu: Xử lý lỗi giải nén PlantVillage thiếu lớp, lỗi Drive
  shortcut, lỗi tham số check_valid không tồn tại

## Phiên 4 — Giai đoạn 4 (Tuần 5): Huấn luyện & Đánh giá, chuyển sang chạy VSCode local
- Công cụ: Claude (Anthropic)
- Ngày: [điền ngày thực tế]
- Mục tiêu: Viết stage4_run_all.py (điều phối 4 bước theo checklist:
  protonet / baseline / evaluate / compare) và compare_results.py
  (dựng bảng so sánh Accuracy + thời gian cho 1-shot/5-shot/10-shot từ
  các file JSON đã lưu ở Giai đoạn 3, không tính toán lại thủ công).
- Thay đổi ở data_prep.py: thêm nhận diện IN_COLAB, cho phép chạy trên
  máy local (VSCode) song song với Colab mà không cần sửa code, chỉ
  cần đặt đúng cấu trúc thư mục data/ cạnh code/ (xem README_VSCODE.md).
- Thay đổi ở train_baseline_finetune.py: thêm train_and_save() (lưu
  backbone MobileNetV2 + cấu hình ft_steps/ft_lr đã tune) và
  load_trained_config() để Người 2 không phải tune lại mỗi lần chạy
  benchmark; tune riêng ft_steps/ft_lr cho từng K (1/5/10) thay vì
  dùng chung 1 cấu hình cho cả 3, để công bằng hơn khi so sánh với
  ProtoNet (vốn cũng được chọn checkpoint riêng theo validation).
- Thay đổi ở train_protonet.py: thêm load_trained_model() để nạp lại
  checkpoint đã lưu mà không cần train lại.
- Lỗi phát sinh & tự sửa: viết bộ test rút gọn (ảnh giả, số epoch/
  episode nhỏ) để chạy thử toàn bộ pipeline Giai đoạn 4 trước khi giao,
  phát hiện tune_hyperparams_on_validation() trong
  train_baseline_finetune.py gọi cứng N_WAY=5 khi đánh giá trên
  validation_classes (Pepper, chỉ có 2 lớp) -> lỗi "Sample larger than
  population", giống lỗi quick_validate() đã gặp ở Phiên 2. Tự sửa
  bằng val_n_way = min(N_WAY, len(validation_classes)), áp dụng đúng
  cách sửa đã dùng cho ProtoNet để 2 phương pháp nhất quán.

## Phiên 5 — Xác nhận nguồn dữ liệu PlantVillage, hướng dẫn Google Drive/Colab
- Công cụ: Claude (Anthropic)
- Ngày: [điền ngày thực tế]
- Mục tiêu: Xác nhận dataset Kaggle abdallahalidev/plantvillage-dataset
  giải nén ra đúng cấu trúc `plantvillage dataset/color/<Loài>___<Bệnh>/`
  mà data_prep.py đang chờ (PLANTVILLAGE_DIR) -> không cần sửa code.
- Viết README_GOOGLE_DRIVE.md: hướng dẫn 2 người dùng chung 1 thư mục
  Drive, tải PlantVillage thẳng từ Kaggle vào Drive bằng Kaggle API
  trong Colab (không cần tải về máy rồi upload lại, tiết kiệm thời
  gian vì PlantVillage khá nặng), và giải thích vì sao models/, results/
  tự động dùng chung được giữa 2 người (MODELS_DIR/RESULTS_DIR trong
  episode_utils.py được suy ra từ DRIVE_BASE_DIR, nên khi chạy trên
  Colab cả 2 đều ghi thẳng vào Drive, không cần đồng bộ tay).
- Viết PERSON2_HUONG_DAN.md: tóm tắt riêng 3 việc của Người 2 (train
  baseline + lưu model, benchmark cả 2 mô hình cùng điều kiện, xem
  bảng kết quả), map rõ từng việc với đúng file/hàm/lệnh chạy, và giải
  thích vì sao việc benchmark + so sánh nên do 1 người (Người 2) chạy
  trên 1 máy duy nhất thay vì 2 người tự benchmark riêng — để cột thời
  gian (mean_inference_time_sec) so sánh được công bằng giữa 2 phương
  pháp, chỉ có Accuracy mới so sánh được nếu benchmark trên 2 máy khác
  nhau.
