# Hướng dẫn chạy qua Google Drive + Colab

Tài liệu này dành cho việc 2 người cùng chia sẻ 1 thư mục Google Drive,
mỗi người train trên Colab của mình, không cần gửi file .pt qua lại
thủ công. Nếu muốn chạy hẳn ở máy cá nhân bằng VSCode, xem
README_VSCODE.md — code giống hệt nhau, chỉ khác đường dẫn gốc, không
cần sửa gì.

## 1. Tạo cấu trúc thư mục dùng chung trên Google Drive

Một trong 2 người tạo thư mục sau trong Google Drive của mình, rồi
"Chia sẻ" (Share) toàn bộ thư mục `DoAn` cho người còn lại với quyền
Editor:

```
MyDrive/
  DoAn/
    data/
      plantvillage/
        plantvillage-dataset.zip
      durian/
        A Durian Leaf Image Dataset of Common Diseases in Vietnam for Agricultural Diagnosis/
          Durian_Leaf_Diseases/
            train/...
            val/...
            test/...
    code/
      data_prep.py
      episode_utils.py
      train_protonet.py
      train_baseline_finetune.py
      stage4_run_all.py
      compare_results.py
```

Người được chia sẻ chọn "Add shortcut to Drive" (hoặc trên giao diện
Drive mới: "Organize > Add shortcut") để thư mục `DoAn` xuất hiện
trong `MyDrive` của chính mình tại đúng đường dẫn
`MyDrive/DoAn/...` — bắt buộc phải đúng đường dẫn này vì code đang
mặc định `DRIVE_BASE_DIR = '/content/drive/MyDrive/DoAn/data'`.

Quan trọng: `models/` và `results/` KHÔNG cần tạo tay — code tự tạo
2 thư mục này ngay cạnh `data/` (tức `MyDrive/DoAn/models`,
`MyDrive/DoAn/results`) và lưu thẳng vào Drive. Vì cả 2 người cùng mở
đúng 1 thư mục Drive share, file .pt của người này train xong sẽ tự
xuất hiện trong Drive của người kia sau khi Drive đồng bộ xong (vài
giây đến vài phút), không cần gửi qua Zalo/USB.

## 2. Tải PlantVillage từ Kaggle thẳng vào Drive (không cần tải về máy)

Dataset dùng: https://www.kaggle.com/datasets/abdallahalidev/plantvillage-dataset

Cách nhanh nhất là tải thẳng trong Colab (mạng Colab nhanh hơn mạng
nhà nhiều), sau đó file zip nằm sẵn trong Drive luôn:

1. Vào https://www.kaggle.com/settings > mục API > bấm "Create New
   Token" — Kaggle sẽ tải về file `kaggle.json` (chứa khoá API của
   riêng bạn, không chia sẻ file này cho ai).
2. Mở 1 notebook Colab mới, chạy lần lượt các ô sau:

```python
from google.colab import drive
drive.mount('/content/drive')
```

```python
# Chạy xong ô này, Colab sẽ hiện nút "Choose Files" — chọn file
# kaggle.json vừa tải ở bước 1
from google.colab import files
files.upload()
```

```python
!pip install -q kaggle
!mkdir -p ~/.kaggle
!cp kaggle.json ~/.kaggle/
!chmod 600 ~/.kaggle/kaggle.json

!mkdir -p "/content/drive/MyDrive/DoAn/data/plantvillage"
!kaggle datasets download -d abdallahalidev/plantvillage-dataset \
    -p "/content/drive/MyDrive/DoAn/data/plantvillage"
```

Lệnh `kaggle datasets download` mặc định lưu ra file tên
`plantvillage-dataset.zip` — đúng khớp tên file mà `data_prep.py`
đang tìm (`PLANTVILLAGE_ZIP`), không cần đổi tên gì thêm.

Chỉ cần làm bước này 1 LẦN DUY NHẤT (người nào tải trước cũng được,
Drive dùng chung nên người kia không cần tải lại).

## 3. Đưa Durian Leaf Dataset lên Drive

Bạn đã có sẵn file zip Durian ở máy — giải nén ra, kéo thả (hoặc dùng
giao diện web Drive để upload) đúng thư mục
`MyDrive/DoAn/data/durian/A Durian Leaf Image Dataset of Common
Diseases in Vietnam for Agricultural Diagnosis/Durian_Leaf_Diseases/`
sao cho bên trong có 3 thư mục con `train/`, `val/`, `test/` như mô tả
ở mục 1. Cũng chỉ cần làm 1 lần.

## 4. Đưa code lên Drive (hoặc GitHub)

Cách đơn giản nhất: kéo thả toàn bộ 6 file `.py` vào
`MyDrive/DoAn/code/` bằng giao diện web Drive.

Cách gọn hơn nếu nhóm đã dùng GitHub: đẩy code lên repo, rồi mỗi
lần mở Colab chỉ cần:

```python
!git clone https://github.com/<ten-nhom>/<ten-repo>.git /content/drive/MyDrive/DoAn/code
```

(hoặc `git pull` nếu đã clone từ trước) để luôn có bản code mới nhất
mà không phải kéo thả tay từng lần.

## 5. Chạy trong Colab

Mỗi lần mở Colab mới, chạy các ô sau (mount Drive + trỏ vào thư mục
code):

```python
from google.colab import drive
drive.mount('/content/drive')

%cd /content/drive/MyDrive/DoAn/code
```

Sau đó chạy đúng phần việc của mình:

```python
# Người 1
!python stage4_run_all.py --stage protonet
```

```python
# Người 2
!python stage4_run_all.py --stage baseline
```

```python
# Người 2 — sau khi CẢ 2 đã train xong (kiểm tra models/ trong Drive
# đã có đủ 3 file: protonet_conv4_best.pt, baseline_mobilenetv2_backbone.pt,
# baseline_finetune_config.json)
!python stage4_run_all.py --stage evaluate
```

```python
# Cả 2 cùng chạy để xem bảng kết quả (chạy trên máy ai cũng ra kết
# quả giống nhau vì cùng đọc chung 1 nơi trong Drive)
!python stage4_run_all.py --stage compare
```

Lưu ý về thời gian chạy trên Colab miễn phí: phiên làm việc có thể bị
ngắt sau một khoảng thời gian không thao tác hoặc hết giờ giới hạn.
Vì `models/` và `results/` được ghi thẳng vào Drive (không phải vào
`/content` sẽ mất khi ngắt phiên), nếu bị ngắt giữa chừng lúc đang
`--stage protonet` hoặc `--stage baseline`, chỉ cần mount lại Drive và
chạy lại đúng lệnh đó — các checkpoint tốt nhất (`_best.pt`) đã lưu từ
trước không mất, nhưng vẫn phải train lại từ đầu epoch 1 vì code hiện
tại chưa hỗ trợ resume giữa chừng epoch.

## 6. Kiểm tra kết quả

Vào `MyDrive/DoAn/results/comparison_table.md` — mở trực tiếp trên
trình duyệt Drive để xem bảng so sánh, hoặc tải về dán vào báo cáo Word.
