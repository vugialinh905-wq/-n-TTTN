# -*- coding: utf-8 -*-
"""
stage4_run_all.py
Giai đoạn 4 — Tuần 5: Huấn luyện & Đánh giá

Ánh xạ đúng theo checklist đã thống nhất:
  [ ] Người 1: Train xong Prototypical Network, lưu model (.pt) vào Drive chung
      -> python stage4_run_all.py --stage protonet

  [ ] Người 2: Train xong baseline fine-tuning ở các cấu hình K, lưu model
      -> python stage4_run_all.py --stage baseline

  [ ] Người 2: Dùng hàm benchmark ở Giai đoạn 3, chạy đánh giá cho CẢ 2
      mô hình trên cùng tập novel classes (Durian), cùng 600 episode,
      cùng điều kiện máy chạy
      -> python stage4_run_all.py --stage evaluate

  [ ] Cả 2 cùng xem bảng kết quả, ghi chú Accuracy + thời gian cho từng
      cấu hình 1-shot/5-shot/10-shot
      -> python stage4_run_all.py --stage compare

Vì sao tách 4 bước riêng thay vì gộp thành 1 hàm main() duy nhất:
Người 1 và Người 2 train trên 2 máy/2 phiên Colab khác nhau, không
cùng lúc. Nếu gộp chung, ai chạy trước sẽ vô tình train luôn phần việc
của người kia. Tách bước --stage giúp mỗi người chỉ chạy đúng phần của
mình, còn bước 'evaluate' và 'compare' chỉ cần các file .pt/.json đã
được lưu vào Drive chung (không cần người kia có mặt cùng lúc).

Cách chạy trong VSCode: xem README_VSCODE.md.
"""

import argparse
import time

from data_prep import set_seed, SEED, mount_drive, extract_datasets_to_local

import train_protonet
import train_baseline_finetune
import compare_results


def stage_protonet():
    """Người 1: chỉ train + lưu model, KHÔNG tự benchmark ở đây — việc
    benchmark cả 2 mô hình dưới cùng điều kiện là việc của Người 2 ở
    bước --stage evaluate, để đảm bảo công bằng (đúng máy, đúng lúc,
    đúng 600 episode, không lẫn với máy của Người 1)."""
    print("=" * 70)
    print("NGƯỜI 1 — TRAIN PROTOTYPICAL NETWORK")
    print("=" * 70)
    train_protonet.train()
    print("\nĐã train xong ProtoNet. Nhớ đồng bộ thư mục models/ và "
          "results/ lên Google Drive chung để Người 2 dùng ở bước "
          "--stage evaluate.")


def stage_baseline():
    """Người 2: train (tune ft_steps/ft_lr riêng cho từng K) + lưu
    backbone và cấu hình, KHÔNG tự benchmark ở đây (xem lý do ở
    stage_protonet)."""
    print("=" * 70)
    print("NGƯỜI 2 — TRAIN BASELINE FINE-TUNING (tune riêng cho K=1,5,10)")
    print("=" * 70)
    train_baseline_finetune.train_and_save()
    print("\nĐã train xong Baseline. Nhớ đồng bộ thư mục models/ và "
          "results/ lên Google Drive chung.")


def stage_evaluate():
    """Người 2: nạp lại CẢ 2 model đã lưu (không train lại), rồi chạy
    evaluate_episodes() — hạ tầng chung ở episode_utils.py — cho cả 2,
    cùng seed, cùng 600 episode, cùng novel classes (Durian), cùng máy
    đang chạy file này. Đây là điều kiện bắt buộc để so sánh công bằng."""
    print("=" * 70)
    print("NGƯỜI 2 — ĐÁNH GIÁ CẢ 2 MÔ HÌNH TRÊN NOVEL CLASSES (DURIAN)")
    print("=" * 70)

    print("\n[1/2] ProtoNet — nạp checkpoint đã lưu, KHÔNG train lại...")
    protonet_model = train_protonet.load_trained_model()
    train_protonet.evaluate(protonet_model)

    print("\n[2/2] Baseline Fine-tuning — nạp backbone + cấu hình đã "
          "lưu, KHÔNG tune lại...")
    base_model, best_params_per_k = train_baseline_finetune.load_trained_config()
    train_baseline_finetune.evaluate(base_model, best_params_per_k)

    print("\nĐã đánh giá xong cả 2 mô hình, kết quả đã lưu vào results/. "
          "Chạy tiếp --stage compare để xem bảng tổng hợp.")


def stage_compare():
    """Cả 2 cùng xem: đọc lại 6 file kết quả đã lưu, dựng 1 bảng duy
    nhất, lưu ra markdown + csv để dán vào báo cáo đồ án."""
    print("=" * 70)
    print("CẢ 2 — BẢNG SO SÁNH KẾT QUẢ CUỐI CÙNG")
    print("=" * 70)
    compare_results.build_comparison_table()


STAGE_FUNCS = {
    'protonet': stage_protonet,
    'baseline': stage_baseline,
    'evaluate': stage_evaluate,
    'compare': stage_compare,
}


def main():
    parser = argparse.ArgumentParser(
        description="Giai đoạn 4 (Tuần 5) — Huấn luyện & Đánh giá"
    )
    parser.add_argument(
        '--stage', type=str, default='all',
        choices=list(STAGE_FUNCS.keys()) + ['all'],
        help="Bước muốn chạy. 'all' chạy tuần tự cả 4 bước — chỉ dùng "
             "để tự kiểm tra pipeline chạy được từ đầu đến cuối trên 1 "
             "máy, KHÔNG dùng 'all' khi 2 người chia nhau train ở 2 nơi."
    )
    args = parser.parse_args()

    set_seed(SEED)
    mount_drive()                # tự bỏ qua nếu không phải Colab
    extract_datasets_to_local()  # giải nén/copy dữ liệu nếu chưa có sẵn

    t0 = time.time()

    if args.stage == 'all':
        for name, func in STAGE_FUNCS.items():
            func()
    else:
        STAGE_FUNCS[args.stage]()

    elapsed_min = (time.time() - t0) / 60
    print(f"\nTổng thời gian chạy bước '{args.stage}': {elapsed_min:.1f} phút")


if __name__ == '__main__':
    main()
