# Việc của Người 2 — Giai đoạn 4 (Tuần 5)

Tài liệu này tóm tắt đúng 3 việc của Người 2 theo checklist, file nào
làm việc đó, và lệnh chạy chính xác. Đọc README_VSCODE.md hoặc
README_GOOGLE_DRIVE.md để biết cách cài đặt môi trường trước.

## Việc 1 — Train baseline fine-tuning ở các cấu hình K, lưu model

File phụ trách: `train_baseline_finetune.py`, hàm `train_and_save()`.

Baseline không có 1 quá trình train dài như ProtoNet, vì backbone
MobileNetV2 dùng pretrained ImageNet và bị đóng băng (không cập nhật
trọng số) — phần "học" thật sự chỉ là fine-tune 1 lớp classifier nhỏ,
và việc này lặp lại MỚI HOÀN TOÀN ở mỗi episode lúc đánh giá (không có
gì để lưu lại từ đó). Vì vậy "train xong, lưu model" ở đây gồm 2 phần:

1. Lưu backbone MobileNetV2 (đã đóng băng) ra
   `models/baseline_mobilenetv2_backbone.pt` — để không phải tải lại
   pretrained weights từ mạng mỗi lần chạy, và đảm bảo Người 1 hay
   giảng viên chấm bài dùng đúng backbone giống hệt lúc train.
2. Với MỖI cấu hình K (1-shot, 5-shot, 10-shot), thử một lưới các cặp
   `(ft_steps, ft_lr)` trên tập validation_classes (Pepper — tách
   riêng từ Giai đoạn 0, không đụng vào Durian), chọn cặp cho accuracy
   trung bình cao nhất, lưu lại vào
   `models/baseline_finetune_config.json`.

Chạy:

```
python stage4_run_all.py --stage baseline
```

Kết quả sau khi chạy xong, kiểm tra có đủ các file:
- `models/baseline_mobilenetv2_backbone.pt`
- `models/baseline_finetune_config.json`
- `results/baseline_tuning_summary_1shot.json`
- `results/baseline_tuning_summary_5shot.json`
- `results/baseline_tuning_summary_10shot.json`

(3 file tuning_summary là bằng chứng đã thật sự thử nhiều cấu hình
trên validation chứ không chọn ft_steps/ft_lr theo cảm tính — nên đưa
vào phụ lục báo cáo.)

## Việc 2 — Benchmark cả 2 mô hình, cùng điều kiện

File phụ trách: `stage4_run_all.py`, hàm `stage_evaluate()`, dùng lại
đúng hàm `evaluate_episodes()` đã viết ở Giai đoạn 3
(`episode_utils.py`) cho cả 2 mô hình — không viết 2 hàm đánh giá
riêng biệt, để chắc chắn không có sai lệch do cách tính khác nhau.

Việc này PHẢI chạy sau khi CẢ 2 người đã xong Việc 1 của mình (Người 1
đã có `models/protonet_conv4_best.pt`, Người 2 đã có
`models/baseline_mobilenetv2_backbone.pt` +
`models/baseline_finetune_config.json`). Nếu dùng Drive dùng chung
(xem README_GOOGLE_DRIVE.md), không cần chờ đợi gì thêm — 2 file này
tự có sẵn trong Drive của cả 2 người.

Chạy:

```
python stage4_run_all.py --stage evaluate
```

Bên trong, lệnh này sẽ:
1. Nạp lại checkpoint ProtoNet đã lưu (`load_trained_model()` trong
   `train_protonet.py`) — KHÔNG train lại.
2. Nạp lại backbone + cấu hình baseline đã lưu
   (`load_trained_config()` trong `train_baseline_finetune.py`) —
   KHÔNG tune lại.
3. Với từng phương pháp, chạy đúng 600 episode/cấu hình, trên đúng
   novel_classes (Durian, 6 lớp bệnh lá), cùng SEED = 42, cùng máy
   (máy Người 2 đang chạy lệnh này) — đúng yêu cầu "cùng điều kiện".
4. Lưu 6 file kết quả vào `results/`:
   `protonet_1shot.json`, `protonet_5shot.json`, `protonet_10shot.json`,
   `baseline_finetune_1shot.json`, `baseline_finetune_5shot.json`,
   `baseline_finetune_10shot.json`.

Mỗi file JSON chứa: `mean_accuracy`, `ci95` (khoảng tin cậy 95%),
`mean_inference_time_sec` (thời gian trung bình mỗi episode), và toàn
bộ danh sách accuracy từng episode (để vẽ biểu đồ phân phối nếu cần).

## Việc 3 — Xem bảng kết quả cùng Người 1

File phụ trách: `compare_results.py`.

```
python stage4_run_all.py --stage compare
```

In ra màn hình bảng Accuracy + thời gian cho cả 6 dòng (2 phương pháp
x 3 cấu hình K), đồng thời lưu:
- `results/comparison_table.md` — dán thẳng vào báo cáo Word/LaTeX
- `results/comparison_table.csv` — mở bằng Excel/Google Sheets để vẽ
  biểu đồ cột so sánh Accuracy giữa 2 phương pháp theo từng K

Không cần tính tay bất kỳ con số nào — bảng này đọc thẳng từ 6 file
JSON đã lưu ở Việc 2, tránh trường hợp 2 người chép số liệu vào báo
cáo bị lệch nhau.

## Vì sao Người 2 làm cả Việc 2 và 3 mà không phải Người 1

Vì Người 2 là người chạy `evaluate_episodes()` lần cuối cho cả 2 mô
hình trên cùng 1 máy, nên "điều kiện máy chạy" (CPU/GPU, thời điểm,
tải máy) là như nhau cho cả 2 phương pháp — nếu để Người 1 tự benchmark
ProtoNet trên máy của Người 1 rồi Người 2 benchmark baseline trên máy
khác, con số thời gian (`mean_inference_time_sec`) sẽ không so sánh
được với nhau (máy khác tốc độ khác nhau), chỉ Accuracy là so sánh
được. Gộp cả 2 vào 1 lần chạy của Người 2 giải quyết luôn vấn đề này.
