# -*- coding: utf-8 -*-
"""
compare_results.py
Giai đoạn 4 — Bảng so sánh kết quả cuối cùng giữa ProtoNet và Baseline
Fine-tuning, trên cùng tập novel classes (Durian), cùng 600 episode,
cùng máy chạy.

Nguyên tắc: KHÔNG tự tính toán lại gì ở đây — chỉ đọc kết quả đã được
evaluate_episodes() (episode_utils.py) lưu sẵn trong results/. Đây là
1 nguồn sự thật duy nhất, tránh việc 2 người tự tính tay rồi chép số
liệu lệch nhau vào báo cáo đồ án.

Yêu cầu trước khi chạy file này: đã chạy xong
  python stage4_run_all.py --stage evaluate
để tạo đủ 6 file kết quả (2 phương pháp x 3 cấu hình K) trong results/.
"""

import csv
import json
import os

from episode_utils import RESULTS_DIR

K_VALUES = [1, 5, 10]

# Tên file đã được lưu bởi save_result() trong train_protonet.py /
# train_baseline_finetune.py — PHẢI khớp chính xác với 2 file đó.
METHOD_FILES = {
    'ProtoNet': 'protonet_{k}shot.json',
    'Fine-tuning (MobileNetV2)': 'baseline_finetune_{k}shot.json',
}


def load_all_results():
    """Đọc toàn bộ 6 file kết quả. Báo lỗi rõ ràng ngay nếu thiếu file
    nào (ví dụ quên chạy --stage evaluate), thay vì âm thầm bỏ qua và
    hiện ra 1 bảng thiếu số liệu gây khó hiểu."""
    results = {}
    missing = []
    for method, pattern in METHOD_FILES.items():
        for k in K_VALUES:
            path = os.path.join(RESULTS_DIR, pattern.format(k=k))
            if not os.path.exists(path):
                missing.append(path)
                continue
            with open(path, 'r', encoding='utf-8') as f:
                results[(method, k)] = json.load(f)

    if missing:
        raise FileNotFoundError(
            "Thiếu file kết quả benchmark, cần chạy trước:\n"
            "  python stage4_run_all.py --stage evaluate\n"
            "Danh sách file còn thiếu:\n"
            + "\n".join(f"  - {p}" for p in missing)
        )
    return results


def build_comparison_table():
    """Dựng bảng so sánh, in ra màn hình, lưu ra results/comparison_table.md
    (dán thẳng vào báo cáo) và results/comparison_table.csv (vẽ biểu đồ)."""
    results = load_all_results()

    rows = []
    for k in K_VALUES:
        for method in METHOD_FILES:
            r = results[(method, k)]
            rows.append({
                'method': method,
                'k_shot': k,
                'n_episodes': r['n_episodes'],
                'accuracy_pct': r['mean_accuracy'] * 100,
                'ci95_pct': r['ci95'] * 100,
                'inference_ms': r['mean_inference_time_sec'] * 1000,
            })

    # --- In ra màn hình ---
    print(f"{'Phuong phap':28s} | {'K':3s} | {'Episode':7s} | "
          f"{'Accuracy':18s} | {'Thoi gian/episode':18s}")
    print("-" * 88)
    for row in rows:
        acc_str = f"{row['accuracy_pct']:.2f}% +/- {row['ci95_pct']:.2f}%"
        time_str = f"{row['inference_ms']:.1f} ms"
        print(f"{row['method']:28s} | {row['k_shot']:<3d} | "
              f"{row['n_episodes']:<7d} | {acc_str:18s} | {time_str:18s}")

    # --- Lưu markdown (dán thẳng vào báo cáo đồ án) ---
    md_path = os.path.join(RESULTS_DIR, 'comparison_table.md')
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write("# Giai đoạn 4 — Bảng so sánh ProtoNet vs Baseline Fine-tuning\n\n")
        f.write("Novel classes: Durian (6 lớp bệnh lá), 5-way, "
                "600 episode/cấu hình, cùng seed, cùng máy chạy.\n\n")
        f.write("| Phương pháp | K-shot | Số episode | Accuracy | Thời gian/episode |\n")
        f.write("|---|---|---|---|---|\n")
        for row in rows:
            acc_str = f"{row['accuracy_pct']:.2f}% ± {row['ci95_pct']:.2f}%"
            time_str = f"{row['inference_ms']:.1f} ms"
            f.write(f"| {row['method']} | {row['k_shot']} | {row['n_episodes']} "
                     f"| {acc_str} | {time_str} |\n")
    print(f"\nĐã lưu bảng markdown tại: {md_path}")

    # --- Lưu CSV (để vẽ biểu đồ ở Excel/Google Sheets nếu cần cho báo cáo) ---
    csv_path = os.path.join(RESULTS_DIR, 'comparison_table.csv')
    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=[
            'method', 'k_shot', 'n_episodes', 'accuracy_pct', 'ci95_pct', 'inference_ms'
        ])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Đã lưu bảng CSV tại: {csv_path}")

    return rows


if __name__ == '__main__':
    build_comparison_table()
